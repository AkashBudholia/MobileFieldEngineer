package com.androidws.data;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.androidws.model.AurdionoModel;

public class ReadingGraphData {
	
	ArrayList<AurdionoModel> list = new ArrayList<AurdionoModel>();
	
	public ArrayList<AurdionoModel> getAllReadingData()
	{
		try{
		    
			   Class.forName("com.mysql.jdbc.Driver");
			   Connection con = DriverManager.getConnection
		               ("jdbc:mysql://10.8.62.79:3306/test","nitman","N!tm@n");
			   PreparedStatement statement =  con.prepareStatement("SELECT * FROM arduino ");
			   ResultSet rs = statement.executeQuery();
			    
			   while(rs.next()){
			   
				   list.add(new AurdionoModel(rs.getString("id"), rs.getString("timeValue"),
						   rs.getString("value")));
				   
			    }
			   System.out.println("List Value is ::"+list);
		
		}catch(Exception e){
			   e.printStackTrace();
		  }
		return list;
	}

}
