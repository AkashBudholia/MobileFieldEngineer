package com.androidws.data;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class Login {
	public String authentication(String userName,String password){
	   
	  String retrievedUserName = "";
	  String retrievedPassword = "";
	  String status = "";
	  try{
	    
	   Class.forName("com.mysql.jdbc.Driver");
	   Connection con = DriverManager.getConnection
               ("jdbc:mysql://10.8.62.79:3306/test","nitman","N!tm@n");
	   PreparedStatement statement =  con.prepareStatement("SELECT * FROM users WHERE username = '"+userName+"'");
	   ResultSet result = statement.executeQuery();
	    
	   while(result.next()){
	    retrievedUserName = result.getString("username");
	    retrievedPassword = result.getString("password");
	    }
	    
	   if(retrievedUserName.equals(userName)&&retrievedPassword.equals(password)){
	    status = "Success!";
	   }
	    
	   else{
	    status = "Login fail!!!";
	   }
	    
	  }
	  catch(Exception e){
	   e.printStackTrace();
	  }
	  return status;
	  
	 }
	 
	}
