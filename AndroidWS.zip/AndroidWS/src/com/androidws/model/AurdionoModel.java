package com.androidws.model;

import java.io.Serializable;

public class AurdionoModel implements Serializable {

	private static final long serialVersionUID = 1L;
	

	private String id;
	private String timeValue;
	private String value;
	
	
	
	
	public AurdionoModel(String id, String timeValue, String value) {
		super();
		this.id = id;
		this.timeValue = timeValue;
		this.value = value;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getTimeValue() {
		return timeValue;
	}
	public void setTimeValue(String timeValue) {
		this.timeValue = timeValue;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	
	
}
