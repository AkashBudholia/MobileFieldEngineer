package com.rpower.utils;


import com.rpower.activity.PermitReturnActivity;
import com.rpower.activity.R;
import com.rpower.activity.SafetyPermitActivity;
import com.rpower.activity.TaggingActivity;
import com.rpower.activity.UnTaggingActivity;
import com.rpower.activity.WorkCompletionActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.view.Menu;
import android.view.MenuItem;


import android.app.Activity;
import android.app.AlertDialog;

public class SharedMenu {
	private static final String TAG = "SharedMenu";

	public SharedMenu() {
		// TODO Auto-generated constructor stub
	}

	public static boolean onCreateOptionsMenu(Menu menu, Activity caller) {
		// Inflate the menu; this adds items to the action bar if it is present.
		caller.getMenuInflater().inflate(R.menu.home, menu);
		return true;
	}

	public static boolean onOptionsItemSelected(MenuItem item,
			final Activity caller) {
		// TODO Auto-generated method stub

		try {
			switch (item.getItemId()) {
			case R.id.menuTaggingData:
				Intent intent_tagging = new Intent(caller,
						TaggingActivity.class);
				caller.startActivity(intent_tagging);
				break;
			case R.id.menuUnTaggingData:
				Intent intent_untaggingData = new Intent(caller,
						UnTaggingActivity.class);
				caller.startActivity(intent_untaggingData);
				break;
			case R.id.menuSafetyPermit:
				Intent intent_safetyPermit = new Intent(caller,
						SafetyPermitActivity.class);
				caller.startActivity(intent_safetyPermit);
				break;
			case R.id.menuPermitReturn:
				Intent intent_permitReturn = new Intent(caller,
						PermitReturnActivity.class);
				caller.startActivity(intent_permitReturn);
				break;
			
			case R.id.menuWocoCompletion:
				Intent intent_workCompletion = new Intent(caller, WorkCompletionActivity.class);				
				caller.startActivity(intent_workCompletion);
				break;
			
			
			case R.id.menulogout:
				SharedMethods.gotoLogin(caller);
				break;

			default:
				break;
			}
		} catch (Exception ex) {
			SharedMethods.writeLog(TAG, ex, caller);
		}

		return true;
	}

}
