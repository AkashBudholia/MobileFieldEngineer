package com.rpower.utils;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.preference.PreferenceManager;

public class RMISSharedPreferences {

	public RMISSharedPreferences() {
		// TODO Auto-generated constructor stub
	}

	static final String PREF_USER_NAME = "username";
	static final String PREF_LOGGED_IN = "login";

	static SharedPreferences getSharedPreferences(Context ctx) {
		return PreferenceManager.getDefaultSharedPreferences(ctx);
	}

	public static void setUserName(Context ctx, String userName) {
		Editor editor = getSharedPreferences(ctx).edit();
		editor.putString(PREF_USER_NAME, userName);
		editor.commit();
	}

	public static void setLoggedInStatus(Context ctx, Boolean status) {
		Editor editor = getSharedPreferences(ctx).edit();
		editor.putBoolean(PREF_LOGGED_IN, status);
		editor.commit();
	}

	public static String getUserName(Context ctx) {
		return getSharedPreferences(ctx).getString(PREF_USER_NAME, "");
	}

	public static Boolean getLoggedInStatus(Context ctx) {
		return getSharedPreferences(ctx).getBoolean(PREF_LOGGED_IN, false);
	}

	public static void clearRMISSharedPreferences(Context ctx) {
		// Clearing all data from Shared Preferences
		Editor editor = getSharedPreferences(ctx).edit();
		editor.clear();
		editor.commit();
	}

}
