package com.rpower.utils;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Environment;

import java.io.File;
import java.io.IOException;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ErrorLogHandler {

	public ErrorLogHandler() {
		// TODO Auto-generated constructor stub
	}

	String filePath = Environment.getExternalStorageDirectory().getPath()
			.toString()
			+ File.separator
			+ "RPOWER"
			+ File.separator
			+ "MFE"
			+ File.separator
			+ "LOG";

	String fileName = "ErrorLog.log";
	Context context;
	File logFile;

	public ErrorLogHandler(Context context) {
		this.context = context;
		File app_directory = new File(filePath);
		if (!app_directory.exists()) {
			app_directory.mkdirs();
		}

		logFile = new File(filePath + File.separator + fileName);
	}

	public void appendLog(String text, StackTraceElement stackTrace) {

		if (!logFile.exists()) {
			try {
				logFile.createNewFile();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		// long filespace=logFile.getTotalSpace();

		try {
			BufferedWriter buf = new BufferedWriter(new FileWriter(logFile,
					true));
			SimpleDateFormat sdf = new SimpleDateFormat(
					"dd/MM/yyyy hh:mm:ss aa");
			String currDate = sdf.format(new Date());
			int LineNumber = stackTrace.getLineNumber();
			String methodName = stackTrace.getMethodName();
			String className = stackTrace.getClassName();
			buf.append("Date: " + currDate + " \r\n" + text + "\r\n "
					+ className + " " + methodName + " " + LineNumber + " \r\n");
			// buf.append(stackTrace.toString()+"\r\n");
			// buf.newLine();
			// buf.append(text);
			// buf.newLine();
			buf.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void errorAlertDialog() {
		AlertDialog ad = new AlertDialog.Builder(context).create();
		ad.setTitle("Error");
		ad.setMessage("Oops!! Error occured. Please contact System Admin.");
		ad.setButton(AlertDialog.BUTTON_POSITIVE, "OK",
				(DialogInterface.OnClickListener) null);
		ad.show();
	}

	public boolean deleteLogFile() {
		File errorLog = new File(filePath + File.separator + fileName);
		if (errorLog.exists()) {
			return logFile.delete();
		} else {
			return false;
		}
	}

}
