package com.rpower.utils;




import com.rpower.activity.LoginActivity;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.util.Log;


public class SharedMethods {

	public static void gotoLogin(Activity caller) {
		((MyApp) caller.getApplication()).setGvEmpCode(null);
		RMISSharedPreferences.clearRMISSharedPreferences(caller);

		// finish all activities
		Intent intent_Logout = new Intent("LOGOUT");
		caller.sendBroadcast(intent_Logout);

		Intent intent_Login = new Intent(caller, LoginActivity.class);
		caller.startActivity(intent_Login);
	}

	public static void writeLog(String TAG, Exception ex, Context caller) {
		ErrorLogHandler log = new ErrorLogHandler(caller);
		Log.e(TAG, "error -- " + ex.getMessage(), ex);
		log.appendLog(TAG + "-Error-" + ex.getMessage(), ex.getStackTrace()[3]);
		log.errorAlertDialog();
	}

	public static void showAlertDialogwithOK(Context context, String tiltle,
			String msg) {
		AlertDialog ad = new AlertDialog.Builder(context).create();
		ad.setTitle(tiltle);
		ad.setMessage(msg);
		ad.setButton(AlertDialog.BUTTON_POSITIVE, "OK",
				(DialogInterface.OnClickListener) null);
		ad.show();
	}

	public static void showAlertDialogwithOkCancel(Context context,
			String tiltle, String msg) {
		AlertDialog ad = new AlertDialog.Builder(context).create();
		ad.setTitle(tiltle);
		ad.setMessage(msg);
		ad.setButton(AlertDialog.BUTTON_POSITIVE, "OK",
				(DialogInterface.OnClickListener) null);
		ad.show();
	}

}
