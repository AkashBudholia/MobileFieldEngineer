package com.rpower.utils;

import android.app.Application;

public class MyApp extends Application {

	public MyApp() {
		// TODO Auto-generated constructor stub
	}
	//global variables	
	private String gvEmpCode;
	
	public String getGvEmpCode() {
		return gvEmpCode;
	}
	public void setGvEmpCode(String gvEmpCode) {
		this.gvEmpCode = gvEmpCode;
	}
	
}
