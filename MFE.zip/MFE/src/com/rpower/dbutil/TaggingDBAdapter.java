package com.rpower.dbutil;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

public class TaggingDBAdapter {
	
	static final String DATABASE_NAME = "DB_MFE.db";
	static final int DATABASE_VERSION = 1;
	public static final int NAME_COLUMN = 1;
	public static final String TABLE_MEMBER = "APP_TAG_ORDER_DETAILS";
	public static final String PERMIT_NO ="PERMIT_NO";
	public static final String PLANT_CODE ="PLANT_CODE";
	public static final String PLANT_DESC ="PLANT_DESC";
	public static final String ORDER_NO ="ORDER_NO";
	public static final String ORDER_DESC ="ORDER_DESC";
	public static final String EQUIP_NO ="EQUIP_NO";
	public static final String EQUIP_DESC ="EQUIP_DESC";
	public static final String ENGG_ID ="ENGG_ID";
	public static final String ENGG_NAME ="ENGG_NAME";
	public static final String DEPARTMENT ="DEPARTMENT";
	
	// TODO: Create public field for each column in your table.
	// SQL Statement to create a new database.
	static final String DATABASE_CREATE = "create table "+"APP_TAG_ORDER_DETAILS"+
	                             "( " +"ID"+" integer primary key autoincrement,"
			+ "PERMIT_NO  text not null ,PLANT_CODE text not null" +
			" PLANT_DESC text not null,ORDER_NO text not null" +
			" ORDER_DESC text not null,EQUIP_NO text not null" +
			" EQUIP_DESC text not null ,ENGG_ID text not null" +
			" ENGG_NAME text not null, DEPARTMENT text null  ); ";
	
	static final String DATABASE_CREATE1 = "create table "+"TAGGING_STATUS"+
			 "( " +"ID"+" integer primary key autoincrement,"+
			" PERMIT_NO text not null,PERMIT_STATUS text not null);";
	// Variable to hold the database instance
	public  SQLiteDatabase db;
	// Context of the application using the database.
	private final Context context;
	// Database open/upgrade helper
	private DataBaseHelper dbHelper;
	
	public  TaggingDBAdapter(Context _context) 
	{
		context = _context;		
		dbHelper = new DataBaseHelper(context, DATABASE_NAME, null, DATABASE_VERSION);
	}
	
	public  TaggingDBAdapter open() throws SQLException 
	{
		db = dbHelper.getWritableDatabase();
		return this;
	}
	
	
	public void insertEntry()
	{
       ContentValues newValues = new ContentValues();
		
		newValues.put("PERMIT_NO","1001" );
		newValues.put("PLANT_CODE","RP11" );
		newValues.put("PLANT_DESC","Rosa Power Plant 1" );
		newValues.put("ORDER_NO","2001" );
		newValues.put("ORDER_DESC","MP - Material for test" );
		newValues.put("EQUIP_NO","RS10008" );
		newValues.put("EQUIP_DESC","U1 SWGr" );
		newValues.put("ENGG_ID","TMRAKESP" );
		newValues.put("ENGG_NAME","Rakesh Singh" );
		newValues.put("DEPARTMENT","ELM" );
		

		// Insert the row into your table
		db.insert("APP_TAG_ORDER_DETAILS", null, newValues);
		///Toast.makeText(context, "Reminder Is Successfully Saved", Toast.LENGTH_LONG).show();
	}
	
	public Cursor readEntry() {

		  String[] allColumns = new String[] {PERMIT_NO,
				  PLANT_CODE,
				  PLANT_DESC,
				  ORDER_NO,
				  ORDER_DESC,
				  EQUIP_NO,
				  EQUIP_DESC,
				  ENGG_ID,
				  ENGG_NAME,
				  DEPARTMENT };

		  Cursor c = db.query(TaggingDBAdapter.TABLE_MEMBER, allColumns, null, null, null,
		    null, null);

		  if (c != null) {
		   c.moveToFirst();
		  }
		  return c;

		 }
	public void close() 
	{
		db.close();
	}

	public  SQLiteDatabase getDatabaseInstance()
	{
		return db;
	}
	
	public void onCreate(SQLiteDatabase db) {

	  db.execSQL(DATABASE_CREATE);
	  db.execSQL(DATABASE_CREATE1);
	 }

	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

	  db.execSQL("DROP TABLE IF EXISTS " + DATABASE_CREATE);
	  db.execSQL("DROP TABLE IF EXISTS " + DATABASE_CREATE1);
	  onCreate(db);

	 }
	
		
}