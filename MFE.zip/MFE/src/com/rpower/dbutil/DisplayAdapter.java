package com.rpower.dbutil;

import java.util.ArrayList;

import com.rpower.activity.R;
import com.rpower.model.TaggingDataModel;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class DisplayAdapter extends BaseAdapter {
	private Context mContext;
	
	ArrayList<String> txt_department;
	ArrayList<String> txt_enggdetails;
	ArrayList<String> txt_enggid;
	ArrayList<String> txt_equipdesc;
	ArrayList<String> txt_equipno;
	ArrayList<String> txt_orderdesc;
	ArrayList<String> txt_orderno;
	ArrayList<String> txt_permitno;
	ArrayList<String> txt_plantcode;
	ArrayList<String> txt_plantdesc;
	

	public DisplayAdapter(Context c,ArrayList<String> txt_department,
			ArrayList<String> txt_enggdetails,
			ArrayList<String> txt_enggid,
			ArrayList<String> txt_equipdesc,
			ArrayList<String> txt_equipno,
			ArrayList<String> txt_orderdesc,
			ArrayList<String> txt_orderno,
			ArrayList<String> txt_permitno,
			ArrayList<String> txt_plantcode,
			ArrayList<String> txt_plantdesc) {
		this.mContext = c;

		this.txt_department=txt_department;
		this.txt_enggdetails = txt_enggdetails;
		this.txt_enggid=txt_enggid;
		this.txt_equipdesc=txt_equipdesc;
		this.txt_equipno=txt_equipno;
		this.txt_orderdesc=txt_orderdesc;
		this.txt_orderno=txt_orderno;
		this.txt_permitno=txt_permitno;
		this.txt_plantcode=txt_plantcode;
		this.txt_plantdesc=txt_plantdesc;
		
	}

	

	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return null;
	}

	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return 0;
	}

	public View getView(int pos, View child, ViewGroup parent) {
		Holder mHolder;
		LayoutInflater layoutInflater;
		if (child == null) {
			layoutInflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			child = layoutInflater.inflate(R.layout.listcell, null);
			mHolder = new Holder();
			mHolder.txt_permitno = (TextView) child.findViewById(R.id.txt_permitno);
			
			child.setTag(mHolder);
		} else {
			mHolder = (Holder) child.getTag();
		}
		
		mHolder.txt_department.setText(txt_department.get(pos));
		mHolder.txt_enggdetails.setText(txt_enggdetails.get(pos));
		mHolder.txt_enggid.setText(txt_enggid.get(pos));
		mHolder.txt_equipdesc.setText(txt_equipdesc.get(pos));
		
		mHolder.txt_equipno.setText(txt_equipno.get(pos));
		mHolder.txt_orderdesc.setText(txt_orderdesc.get(pos));
		mHolder.txt_orderno.setText(txt_orderno.get(pos));
		mHolder.txt_permitno.setText(txt_permitno.get(pos));
		mHolder.txt_plantcode.setText(txt_plantcode.get(pos));
		mHolder.txt_plantdesc.setText(txt_plantdesc.get(pos));
		
		
		return child;
	}

	public class Holder {
		
		 TextView txt_department;
		 TextView txt_enggdetails;
		 TextView txt_enggid;
		 TextView txt_equipdesc;
		 TextView txt_equipno;
		 TextView txt_orderdesc;
		 TextView txt_orderno;
		 TextView txt_permitno;
		 TextView txt_plantcode;
		 TextView txt_plantdesc;
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return 0;
	}

}
