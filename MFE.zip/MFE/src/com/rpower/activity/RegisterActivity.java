package com.rpower.activity;

import com.rpower.dbutil.LoginDataBaseAdapter;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class RegisterActivity extends Activity {

	EditText editTextUserName,editTextPassword,editTextMobileNo;
	Button btnCreateAccount;
	LoginDataBaseAdapter loginDataBaseAdapter;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_register);
		// get Instance  of Database Adapter
		loginDataBaseAdapter=new LoginDataBaseAdapter(this);
		loginDataBaseAdapter=loginDataBaseAdapter.open();
		// Get Refferences of Views
		editTextUserName=(EditText)findViewById(R.id.mtxtEmpCode);
		editTextPassword=(EditText)findViewById(R.id.mtxtPassword);
		editTextMobileNo=(EditText)findViewById(R.id.mtxtMobileNo);
		btnCreateAccount=(Button)findViewById(R.id.btnRegister);
		btnCreateAccount.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				// TODO Auto-generated method stub
	 
				String userName=editTextUserName.getText().toString();
				String password=editTextPassword.getText().toString();
				String mobileNo=editTextMobileNo.getText().toString();
	 
				// check if any of the fields are vaccant
				if(userName.equals("")||password.equals("")||mobileNo.equals(""))
				{
						Toast.makeText(getApplicationContext(), "Field Vaccant", Toast.LENGTH_LONG).show();
						return;
				}
				// check if both password matches
				
				else
				{
				    // Save the Data in Database
				    loginDataBaseAdapter.insertEntry(userName, password);
				    Toast.makeText(getApplicationContext(), "Account Successfully Created ", Toast.LENGTH_LONG).show();
				    Intent intentSignUP=new Intent(getApplicationContext(),LoginActivity.class);
					startActivity(intentSignUP); 
					
				}
			}
		});
		}
	
	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
 
		loginDataBaseAdapter.close();
	}
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.register, menu);
		return true;
	}

}
