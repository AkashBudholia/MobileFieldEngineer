package com.rpower.activity;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class PermitReturnActivity extends Activity {

	 SQLiteDatabase dbpr;
	  TextView tvpr;
	  EditText etpr;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_permit_return);
		
		tvpr=(TextView)findViewById(R.id.textViewpr);
		   etpr=(EditText)findViewById(R.id.mtxtPermitReturnCode);
		   dbpr= openOrCreateDatabase("DB_MFE.db", MODE_PRIVATE, null);
		   //create new table if not already exist
		   dbpr.execSQL("create table if not exists APP_PERMITRETURN( PERMIT_NO VARCHAR , PLANT_CODE VARCHAR ," +
		   		"	 PLANT_DESC VARCHAR ,	 ORDER_NO VARCHAR ,	 ORDER_DESC VARCHAR ," +
		   		"	 EQUIP_NO VARCHAR ,	 EQUIP_DESC VARCHAR ,	 ENGG_ID VARCHAR ," +
		   		"	 ENGG_NAME VARCHAR ,	 DEPARTMENT VARCHAR )");
		  
		   etpr.setText("");
		  // db.execSQL("insert into  APP_TAGDATA ('"+"1001"+"','"+"RP01"+"','"+"Rosa Power Plant"+"','"+"OD001"+"','"+"Test"+"','"+"Test"+"','"+"Test Order"+"','"+"EQ001"+"','"+"Test Equipment"+"','"+"Test"+"')");
		   dbpr.execSQL("insert into  APP_PERMITRETURN (PERMIT_NO,PLANT_CODE,PLANT_DESC,ORDER_NO," +
			   		" ORDER_DESC,EQUIP_NO,EQUIP_DESC,ENGG_ID,ENGG_NAME,DEPARTMENT) " +
			   		"values ('P004','RP-1','RSPL Rosa Power Plant','7580','Material for test RP11','RS10BBA','U1 SWGA AA','TMRAKESH','RAKESH RAUSHAN','ELM')");
			   
		   dbpr.execSQL("insert into  APP_PERMITRETURN (PERMIT_NO,PLANT_CODE,PLANT_DESC,ORDER_NO," +
				   		" ORDER_DESC,EQUIP_NO,EQUIP_DESC,ENGG_ID,ENGG_NAME,DEPARTMENT) " +
				   		"values ('P005','SP-1','SPPL Sasan Power Plant','7580','Material for test RP11','RS10BBA','U1 SWGA AA','TMRAKESH','RAKESH RAUSHAN','ELM')");
			   
			   
		   dbpr.execSQL("insert into  APP_PERMITRETURN (PERMIT_NO,PLANT_CODE,PLANT_DESC,ORDER_NO," +
				   		" ORDER_DESC,EQUIP_NO,EQUIP_DESC,ENGG_ID,ENGG_NAME,DEPARTMENT) " +
				   		"values ('P006','BP-1','Butobori Power Plant','7580','Material for test RP11','RS10BBA','U1 SWGA AA','TMRAKESH','RAKESH RAUSHAN','ELM')");
		   Toast.makeText(this, "values inserted successfully.", Toast.LENGTH_LONG).show();
	}
	
	public void onPRBtnClick(View v)
	   {
		 etpr=(EditText)findViewById(R.id.mtxtPermitReturnCode);
		 String permitNo ="P004";
		 Toast.makeText(this, "Permit No is ::"+permitNo, Toast.LENGTH_LONG).show();
		 System.out.println("Permit No ::"+permitNo);
		 Cursor c=dbpr.rawQuery("select * from APP_PERMITRETURN where PERMIT_NO='"+permitNo+"'", null);
		   tvpr.setText("");
		   //move cursor to first position
		   c.moveToFirst();
		   //fetch all data one by one
		   do
		   {
		    
			   String PERMIT_NO =c.getString(c.getColumnIndex("PERMIT_NO"));
			   String PLANT_CODE=c.getString(1);
			   String PLANT_DESC = c.getString(2);
			   String ORDER_NO = c.getString(3);
				 String ORDER_DESC = c.getString(4);
				 String EQUIP_NO = c.getString(5);
				 String EQUIP_DESC = c.getString(6);
				 String ENGG_ID = c.getString(7);
				 String ENGG_NAME = c.getString(8);
				 String DEPARTMENT = c.getString(9);
			    //display on text view
			    tvpr.append("Permit No:   "+PERMIT_NO+ "\n"+ "Plant Code : "+PLANT_CODE+"\n"+
			    		"Plant Desc:   "+PLANT_DESC+ "\n"+
			    		"Order No:   "+ORDER_NO+ "\n"+
			    		"Order Desc:   "+ORDER_DESC+ "\n"+
			    		"Equip No:   "+EQUIP_NO+ "\n"+
			    		"Equip Desc:   "+EQUIP_DESC+ "\n"+
			    		"Engg Id:   "+ENGG_ID+ "\n"+
			    		"Engg Name:   "+ENGG_NAME+ "\n"+
			    		"Department:   "+DEPARTMENT+ "\n"
			    		);
		   }while(c.moveToNext());
		  
	   }

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.permit_return, menu);
		return true;
	}
	
public boolean onOptionsItemSelected(MenuItem item) {
		
		try {
			switch (item.getItemId()) {
			case R.id.menuTaggingData:
				Toast.makeText(getApplicationContext(), "Tagging menu item pressed", Toast.LENGTH_SHORT).show();
				Intent intent_tagging = new Intent(getApplicationContext(),
						TaggingActivity.class);
				startActivity(intent_tagging);
				break;
			case R.id.menuUnTaggingData:
				Toast.makeText(getApplicationContext(), "UnTagging menu item pressed", Toast.LENGTH_SHORT).show();
				Intent intent_untaggingData = new Intent(getApplicationContext(),
						UnTaggingActivity.class);
				startActivity(intent_untaggingData);
				break;
			case R.id.menuSafetyPermit:
				Toast.makeText(getApplicationContext(), "Safety Permit menu item pressed", Toast.LENGTH_SHORT).show();
				Intent intent_safetyPermit = new Intent(getApplicationContext(),
						SafetyPermitActivity.class);
				startActivity(intent_safetyPermit);
				break;
			case R.id.menuPermitReturn:
				Toast.makeText(getApplicationContext(), "Permit Return menu item pressed", Toast.LENGTH_SHORT).show();
				Intent intent_permitReturn = new Intent(getApplicationContext(),
						PermitReturnActivity.class);
				startActivity(intent_permitReturn);
				break;
			
			case R.id.menuWocoCompletion:
				Toast.makeText(getApplicationContext(), "WoCo Completion menu item pressed", Toast.LENGTH_SHORT).show();
				Intent intent_workCompletion = new Intent(getApplicationContext(), WorkCompletionActivity.class);				
				startActivity(intent_workCompletion);
				break;
			
			
			case R.id.menulogout:
				Toast.makeText(getApplicationContext(), "LogOut menu item pressed", Toast.LENGTH_SHORT).show();
				Intent intent_logout = new Intent(getApplicationContext(), LoginActivity.class);				
				startActivity(intent_logout);
				//SharedMethods.gotoLogin(caller);
				break;

			default:
				break;
			}
		} catch (Exception ex) {
			//SharedMethods.writeLog(TAG, ex, caller);
		}
		return super.onOptionsItemSelected(item);

	}

}
