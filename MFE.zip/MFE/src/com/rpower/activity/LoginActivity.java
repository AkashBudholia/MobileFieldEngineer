package com.rpower.activity;




import com.rpower.dbutil.LoginDataBaseAdapter;
import com.rpower.utils.RMISSharedPreferences;
import com.rpower.utils.SharedMenu;
import com.rpower.utils.SharedMethods;

import android.os.Bundle;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class LoginActivity extends Activity {

	private static final String TAG = "LoginActivity";
	Button btnSignIn,btnSignUp;
	LoginDataBaseAdapter loginDataBaseAdapter;
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        try {
        	loginDataBaseAdapter=new LoginDataBaseAdapter(this);
   	     loginDataBaseAdapter=loginDataBaseAdapter.open();
			try {
				//objdbAdapter.open();
			} catch (Exception ex) {
				SharedMethods.writeLog(TAG, ex, LoginActivity.this);
			}
			
			if (RMISSharedPreferences
					.getLoggedInStatus(getApplicationContext())) {
				
			}
			
		} catch (Exception ex) {
			SharedMethods.writeLog(TAG, ex, LoginActivity.this);
		}
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
    	SharedMenu.onCreateOptionsMenu(menu, LoginActivity.this);
		return true;
       
    }
    
    @Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// TODO Auto-generated method stub
		SharedMenu.onOptionsItemSelected(item, LoginActivity.this);
		return true;
	}

	@Override
	protected void onResume() {
		try {
			//objdbAdapter.open();
		} catch (Exception ex) {
			SharedMethods.writeLog(TAG,ex,LoginActivity.this);
		}
		super.onResume();
	}
    
    public void onHyperLinkClick(View view) {
		try {
			final Context context = this;
			switch (view.getId()) {
			case R.id.hlRegisterHere:
				Intent intent_register = new Intent(context,
						RegisterActivity.class);
				startActivity(intent_register);
				break;
			case R.id.hlForgotPassword:
				Intent intent_forgotPassword = new Intent(context,
						ForgotPasswordActivity.class);
				startActivity(intent_forgotPassword);
				break;
			}
		} catch (Exception ex) {
			SharedMethods.writeLog(TAG, ex, LoginActivity.this);
		}
	}
    
    public void onBtnClick(View view) {
		try {
			switch (view.getId()) {
			case R.id.btnLogin:

				EditText mEmpCodeView = (EditText) findViewById(R.id.mtxtEmpCodeLogin);
				EditText mPasswordView = (EditText) findViewById(R.id.mtxtPasswordLogin);
				// validations

				String strValidateMsg = validate();
				if (strValidateMsg != "") {
					SharedMethods.showAlertDialogwithOK(LoginActivity.this,
							"Login", strValidateMsg);
					return;
				}

				String userName=mEmpCodeView.getText().toString();
				String password=mPasswordView.getText().toString();
				
				// check
				String storedPassword=loginDataBaseAdapter.getSinlgeEntry(userName);
				if (password.equals(storedPassword)) {
					// setting global variable
					
					// setting shared preferences
					RMISSharedPreferences.setUserName(getApplicationContext(),
							mEmpCodeView.getText().toString());
					RMISSharedPreferences.setLoggedInStatus(
							getApplicationContext(), true);
					 Intent intentHome=new Intent(getApplicationContext(),HomeActivity.class);
						startActivity(intentHome); 

				} else {					
					SharedMethods.showAlertDialogwithOK(LoginActivity.this,
							"Login", "Wrong Employee Code or Password");
					return;
				}
				break;
			}

		} catch (Exception ex) {
			SharedMethods.writeLog(TAG, ex, LoginActivity.this);
		}

	}
    
    
    public String validate() {
		String strMessage = "";
		try {
			EditText mEmpCodeView = (EditText) findViewById(R.id.mtxtEmpCodeLogin);
			EditText mPasswordView = (EditText) findViewById(R.id.mtxtPasswordLogin);

			// validations
			if (mEmpCodeView.getText().length() == 0) {
				strMessage = "Please enter a Employee Code.";
				return strMessage;
			}
			if (mPasswordView.getText().length() == 0) {
				strMessage = "Please enter a Password.";
				return strMessage;
			}

		} catch (Exception ex) {
			SharedMethods.writeLog(TAG, ex, LoginActivity.this);
		}
		return strMessage;
	}
    
   
    
}
