package com.rpower.activity;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

public class ForgotPasswordActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_forgot_password);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.forgot_password, menu);
		return true;
	}
	
public boolean onOptionsItemSelected(MenuItem item) {
		
		try {
			switch (item.getItemId()) {
			case R.id.menuTaggingData:
				Toast.makeText(getApplicationContext(), "Tagging menu item pressed", Toast.LENGTH_SHORT).show();
				Intent intent_tagging = new Intent(getApplicationContext(),
						TaggingActivity.class);
				startActivity(intent_tagging);
				break;
			case R.id.menuUnTaggingData:
				Toast.makeText(getApplicationContext(), "UnTagging menu item pressed", Toast.LENGTH_SHORT).show();
				Intent intent_untaggingData = new Intent(getApplicationContext(),
						UnTaggingActivity.class);
				startActivity(intent_untaggingData);
				break;
			case R.id.menuSafetyPermit:
				Toast.makeText(getApplicationContext(), "Safety Permit menu item pressed", Toast.LENGTH_SHORT).show();
				Intent intent_safetyPermit = new Intent(getApplicationContext(),
						SafetyPermitActivity.class);
				startActivity(intent_safetyPermit);
				break;
			case R.id.menuPermitReturn:
				Toast.makeText(getApplicationContext(), "Permit Return menu item pressed", Toast.LENGTH_SHORT).show();
				Intent intent_permitReturn = new Intent(getApplicationContext(),
						PermitReturnActivity.class);
				startActivity(intent_permitReturn);
				break;
			
			case R.id.menuWocoCompletion:
				Toast.makeText(getApplicationContext(), "WoCo Completion menu item pressed", Toast.LENGTH_SHORT).show();
				Intent intent_workCompletion = new Intent(getApplicationContext(), WorkCompletionActivity.class);				
				startActivity(intent_workCompletion);
				break;
			
			
			case R.id.menulogout:
				Toast.makeText(getApplicationContext(), "LogOut menu item pressed", Toast.LENGTH_SHORT).show();
				Intent intent_logout = new Intent(getApplicationContext(), LoginActivity.class);				
				startActivity(intent_logout);
				//SharedMethods.gotoLogin(caller);
				break;

			default:
				break;
			}
		} catch (Exception ex) {
			//SharedMethods.writeLog(TAG, ex, caller);
		}
		return super.onOptionsItemSelected(item);

	}

}
