package com.rpower.model;

public class TaggingDataModel {
	
	private String PERMIT_NO;
	private String PLANT_CODE;
	private String PLANT_DESC;
	private String ORDER_NO;
	private String ORDER_DESC;
	private String EQUIP_NO;
	private String EQUIP_DESC;
	private String ENGG_ID;
	private String ENGG_NAME;
	private String DEPARTMENT;
	
	public TaggingDataModel(String pERMIT_NO, String pLANT_CODE,
			String pLANT_DESC, String oRDER_NO, String oRDER_DESC,
			String eQUIP_NO, String eQUIP_DESC, String eNGG_ID,
			String eNGG_NAME, String dEPARTMENT) {
		super();
		PERMIT_NO = pERMIT_NO;
		PLANT_CODE = pLANT_CODE;
		PLANT_DESC = pLANT_DESC;
		ORDER_NO = oRDER_NO;
		ORDER_DESC = oRDER_DESC;
		EQUIP_NO = eQUIP_NO;
		EQUIP_DESC = eQUIP_DESC;
		ENGG_ID = eNGG_ID;
		ENGG_NAME = eNGG_NAME;
		DEPARTMENT = dEPARTMENT;
	}

	public String getPERMIT_NO() {
		return PERMIT_NO;
	}

	public void setPERMIT_NO(String pERMIT_NO) {
		PERMIT_NO = pERMIT_NO;
	}

	public String getPLANT_CODE() {
		return PLANT_CODE;
	}

	public void setPLANT_CODE(String pLANT_CODE) {
		PLANT_CODE = pLANT_CODE;
	}

	public String getPLANT_DESC() {
		return PLANT_DESC;
	}

	public void setPLANT_DESC(String pLANT_DESC) {
		PLANT_DESC = pLANT_DESC;
	}

	public String getORDER_NO() {
		return ORDER_NO;
	}

	public void setORDER_NO(String oRDER_NO) {
		ORDER_NO = oRDER_NO;
	}

	public String getORDER_DESC() {
		return ORDER_DESC;
	}

	public void setORDER_DESC(String oRDER_DESC) {
		ORDER_DESC = oRDER_DESC;
	}

	public String getEQUIP_NO() {
		return EQUIP_NO;
	}

	public void setEQUIP_NO(String eQUIP_NO) {
		EQUIP_NO = eQUIP_NO;
	}

	public String getEQUIP_DESC() {
		return EQUIP_DESC;
	}

	public void setEQUIP_DESC(String eQUIP_DESC) {
		EQUIP_DESC = eQUIP_DESC;
	}

	public String getENGG_ID() {
		return ENGG_ID;
	}

	public void setENGG_ID(String eNGG_ID) {
		ENGG_ID = eNGG_ID;
	}

	public String getENGG_NAME() {
		return ENGG_NAME;
	}

	public void setENGG_NAME(String eNGG_NAME) {
		ENGG_NAME = eNGG_NAME;
	}

	public String getDEPARTMENT() {
		return DEPARTMENT;
	}

	public void setDEPARTMENT(String dEPARTMENT) {
		DEPARTMENT = dEPARTMENT;
	}
	
	
	

}
